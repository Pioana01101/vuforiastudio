// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available
var $ionicGesture = $injector.get('$ionicGesture'); //Import from embedded ionic framework v1

// register gestures before loading the experience
$scope.$on("$ionicView.beforeEnter", function (event) {
  // get the element ion-content of experience which is able to handle the $inoicGestures module
  let viewIonContent = angular.element(document.querySelectorAll('ion-content')[0]);
  // all available keywords 
  let availableGestures = ["hold", "tap", "doubletap", "drag", "dragstart", "dragend", "dragup", "dragdown", "dragleft", "dragright", "swipe", "swipeup", "swipedown", "swipeleft", "swiperight", "transform", "transformstart", "transformend", "rotate", "pinch", "pinchin", "pinchout", "touch", "release"];
  
  // register all events as showcase
  for(let i = 0; i < availableGestures.length; i++) {
    $ionicGesture.on(availableGestures[i], function(event){
      // apply it to widget $scope
      $scope.$apply(function () {
        $scope.view.wdg['label-1'].text = availableGestures[i];
      });
    }, viewIonContent);
  }
  
  // ---------- Example without for loop to register a specific one------------------
/*  $ionicGesture.on("swiperight", function(event){
    $scope.$apply(function () {
      $scope.view.wdg['label-1'].text = "swiperight";
    });
  }, viewIonContent);*/
});