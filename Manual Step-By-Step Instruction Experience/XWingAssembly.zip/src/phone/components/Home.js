// Example model created by Keith Moore: https://grabcad.com/library/x-wing-fighter-4

// Experience created by Patrick Scheper

// --------------------------

// The step titles and descriptions defined in an array. 

var steps = [
  {
    "Title": "Locate X-Wing Chassis",
    "Description": "Find the chassis from the box."}
  ,
  {
    "Title": "Assemble Right Lower Wing",
    "Description": "Locate the right lower wing from the box and assemble."}
  ,  
  {
    "Title": "Assemble Left Lower Wing",
    "Description": "Locate the left lower wing from the box and assemble."}
  ,
  {
    "Title": "Assemble Right Upper Wing",
    "Description": "Locate the right upper wing from the box and assemble."}
  ,
  {
    "Title": "Assemble Left Upper Wing",
    "Description": "Locate the left upper wing from the box and assemble."}
  ,
  {
    "Title": "Assemble Cockpit",
    "Description": "Locate the chair and window of the cockpit and assemble."}
  ,
  {
    "Title": "Insert R2-D2",
    "Description": "Locate the R2-D2 droid and assemble."}
  ,
];

// Sets up the title and description application parameters that are bound to the 2D labels. This function gets called 1 milisecond after the experience is loaded.

$timeout(function() {
  $scope.app.params['stepTitle'] = steps[0].Title;
  $scope.app.params['stepDescription'] = steps[0].Description;
}, 1);

// Fires a service broadcast that plays next animation sequence, and also sets the title and description application parameters that are bound to the 2D labels. This gets fired when the next step button is pressed.

$scope.nextStep = function ()
{
  $scope.$root.$broadcast('app.view["Home"].wdg["model-1"].svc.play');
  
   $scope.app.params['stepTitle'] = steps[$scope.view.wdg['model-1']['currentStep']].Title;
  $scope.app.params['stepDescription'] = steps[$scope.view.wdg['model-1']['currentStep']].Description;

  TurnOffButtons();
}

// Fires a service broadcast that rewinds the animation sequence, and also sets the title and description application parameters that are bound to the 2D labels. This gets fired when the go back button is pressed.

$scope.previousStep = function ()
{
  $scope.$root.$broadcast('app.view["Home"].wdg["model-1"].svc.rewind');
  
  $scope.app.params['stepTitle'] = steps[$scope.view.wdg['model-1']['currentStep'] - 2].Title;
  $scope.app.params['stepDescription'] = steps[$scope.view.wdg['model-1']['currentStep'] - 2].Description;
 
  TurnOffButtons();
}

// Turns on the buttons via two application parameters which are bound to the button 'disabled' property.

function TurnOnButtons()
{
  $scope.app.params['previousBtnActive'] = false;
  $scope.app.params['nextBtnActive'] = false;
}

// Turns off the buttons via two application parameters which are bound to the button 'disabled' property.

function TurnOffButtons()
{
  $scope.app.params['previousBtnActive'] = true;
  $scope.app.params['nextBtnActive'] = true;
}

// Turns on back the buttons after the animation sequence is finished. This is bound to the 'playstopped' event is fired via the inspector.

$scope.sequenceFinished = function ()
{
  console.log($scope.view.wdg['model-1']['currentStep']);
  TurnOnButtons();
}
