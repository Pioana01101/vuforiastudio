// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

var $filter = $injector.get('$filter');
var audioWidget;
var currentStep = 0;

$scope.$on("$ionicView.afterEnter", function (event) {
  // rel: https://developer.mozilla.org/en-US/docs/Web/API/HTMLAudioElement
  // rel: https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement
  audioWidget = new Audio();
  // This event triggers if the audio file is loaded and than play it
  audioWidget.addEventListener('loadeddata', () => {
    audioWidget.play();
  });
  // some deeper example if currentTime in relevant in UI
  audioWidget.addEventListener('timeupdate', () => {
    $scope.$apply(function(){
      $scope.view.wdg['3DLabel-1'].text = $filter('date')(new Date(0, 0, 0).setSeconds(audioWidget.currentTime), 'mm:ss') + " / " + $filter('date')(new Date(0, 0, 0).setSeconds(audioWidget.duration), 'mm:ss') ;
    }); 
  })
});


$scope.app.nextStep = function(){
  currentStep++;
  $scope.Stephelper(currentStep)
}

$scope.app.prevStep = function(){
  if(currentStep > 1)
    currentStep--;
  $scope.Stephelper(currentStep)
}

$scope.Stephelper = function(step) {
  switch(step) {
    case 1:
      // Bensound.com
      audioWidget.src = "app/resources/Uploaded/bensound-summer.mp3"
      break;
    case 2:
      audioWidget.src = "app/resources/Uploaded/horse.mp3"
      break;
    default:
      alert('no case found for specific step number');	
    }
}

$scope.app.audioControl = function(widgetId) {
  if($scope.view.wdg['3DButton-3'].text == "Pause") {
  	audioWidget.pause();
    $scope.view.wdg['3DButton-3'].text = "Play";
  }
  else {
    audioWidget.play();
    $scope.view.wdg['3DButton-3'].text = "Pause";
  }
}